# Thai Education QA Dataset (Sample)

A sample dataset for fine-tuning and evaluating Large Language Models on Thai
educational management question-answering tasks. Modeled after the VietEduFrame
dataset from Do, Nguyen & Dam (2025), arXiv:2501.15022.

## Files

| File | Format | Purpose |
|------|--------|---------|
| `raw_regulations.json` | JSON | Source documents — 10 sample regulation articles from a Thai university |
| `thai_edu_qa.jsonl` | JSONL | 30 Context-Question-Answer triples derived from the regulations |

## Schema

### `raw_regulations.json`
```json
{
  "institution": str,
  "document_title": str,
  "version": str,
  "articles": [
    {
      "id": str,                // e.g. "art_02"
      "chapter": str,
      "article_no": str,        // e.g. "ข้อ 5"
      "title": str,
      "body": str               // The actual regulation text in Thai
    }
  ]
}
```

### `thai_edu_qa.jsonl`
One JSON object per line:
```json
{
  "id": str,                    // e.g. "qa_001"
  "article_id": str,            // Links back to raw_regulations.json
  "context": str,               // The regulation paragraph in Thai
  "question": str,              // Natural language question in Thai
  "answer": str,                // Expected answer in Thai
  "quality": str,               // "very_good" | "good" | "medium" | "bad" | "very_bad"
  "split": str                  // "train" | "val" | "test"
}
```

## Statistics

- **Total examples**: 30
- **Train / Val / Test**: 20 / 5 / 5
- **Quality**: 25 very_good, 5 good
- **Avg context length**: 251 chars
- **Avg question length**: 45 chars
- **Avg answer length**: 87 chars

## Coverage

The dataset covers 10 categories of Thai university regulations:

| Article ID | Topic (Thai) | Topic (English) |
|------------|--------------|-----------------|
| art_01 | ขอบเขตการบังคับใช้ | Scope of application |
| art_02 | ภาคการศึกษา | Academic semesters |
| art_03 | หน่วยกิตและภาระการเรียน | Credit hours & load |
| art_04 | ระบบการให้คะแนน | Grading system |
| art_05 | การพ้นสภาพนิสิต | Academic dismissal |
| art_06 | เงื่อนไขการสำเร็จการศึกษา | Graduation requirements |
| art_07 | การทุจริตในการสอบ | Exam cheating penalties |
| art_08 | การลาพักการศึกษา | Leave of absence |
| art_09 | การถอนรายวิชา | Course withdrawal |
| art_10 | การได้รับเกียรตินิยม | Honors |

## Note on Scale

This is a **demonstration sample** sized for tutorial and unit-test purposes.
A production-grade dataset following the VietEduFrame paper would target
~1,000–1,500 examples across 5+ partner institutions, with multiple
human reviewers per example. See `docs/methodology.md` for the full
construction pipeline.
