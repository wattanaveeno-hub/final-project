# Speaker Scripts — LLM for Thai Education Management

**Presentation:** LLM for Management System in Thai Language
**Based on:** Do, Nguyen & Dam (2025). arXiv:2501.15022
**Total slides:** 18
**Estimated total time:** ~18–22 minutes + Q&A

---

## How to use this document

For each slide, there are three blocks:

- 🇹🇭 **Thai script** — for Thai-speaking audiences (Thai committee, supervisor meetings)
- 🇬🇧 **English script** — for international audiences (conferences, English-speaking advisors)
- 📝 **Speaker notes** — emphasis cues, transition lines, likely questions

> The two scripts are **parallel translations**, not different content. You can switch between them mid-talk if the room is mixed (e.g., open in Thai, code slides in English).

---

# Slide 1 — Title

**Time:** ~30 seconds

### 🇹🇭 Thai
> สวัสดีครับ/ค่ะ ผม [ชื่อ] จาก [สังกัด] วันนี้จะมานำเสนองานวิจัยในหัวข้อ
> **"LLM for Management System in Thai Language"** — การประยุกต์ใช้
> Large Language Models กับงานบริหารจัดการการศึกษาภาษาไทย ในสภาพแวดล้อม
> ที่มีทรัพยากรจำกัด
>
> งานนี้ต่อยอดจากเปเปอร์ของทีม VNU Hanoi ที่ตีพิมพ์ในเดือนมกราคม 2025
> ขอเริ่มจากภาพรวมของโปรเจคก่อนนะครับ

### 🇬🇧 English
> Good morning/afternoon. I'm [name] from [affiliation]. Today I'll be
> presenting **"LLM for Management System in Thai Language"** —
> adapting Large Language Models to Thai educational management in a
> low-resource setting.
>
> This project builds directly on the VietEduFrame paper from the VNU
> Hanoi team, published in January 2025. Let me start with an overview.

### 📝 Speaker notes
- **Energy:** confident, warm; this is your hook slide
- **Pause** for ~1 second after "low-resource setting" to let the title land
- The citation at the bottom is in case anyone wants the paper now; don't dwell on it

---

# Slide 2 — Agenda

**Time:** ~45 seconds

### 🇹🇭 Thai
> การนำเสนอวันนี้แบ่งออกเป็น 8 หัวข้อ
>
> เริ่มจาก **Background & Motivation** ว่าทำไม LLM ถึงสำคัญในงานการศึกษา
> ตามด้วย **Problem Statement** ระบุปัญหาเฉพาะของบริบทไทย
>
> หัวข้อที่ 3 จะสรุป **เปเปอร์ต้นฉบับ** ที่เป็นรากฐานของโปรเจค
> หัวข้อที่ 4–5 อธิบาย **framework และ dataset** ที่ผมจะสร้าง
>
> ส่วนหลังเป็น technical: หัวข้อที่ 6 จะแสดง **methodology พร้อมโค้ดจริง**
> หัวข้อที่ 7 พูดถึง **evaluation** และหัวข้อที่ 8 ปิดด้วย **timeline และข้อจำกัด**
>
> รวมเวลาประมาณ 20 นาที จากนั้นเปิด Q&A ครับ

### 🇬🇧 English
> Today's talk covers 8 sections.
>
> We'll start with **Background and Motivation** — why LLMs matter in
> education — followed by **Problem Statement**, where I'll identify the
> specific gaps in the Thai context.
>
> Section 3 summarizes the **reference paper** that this project builds on.
> Sections 4–5 walk through the **framework and dataset** I propose.
>
> The second half is technical: Section 6 shows the **methodology with
> working code**, Section 7 covers **evaluation**, and Section 8 closes
> with **timeline and limitations**.
>
> The talk runs about 20 minutes, then I'll open the floor for Q&A.

### 📝 Speaker notes
- Sweep the room with your eyes during the agenda — this is rapport-building
- Don't read every bullet. Group: "background, problem, paper" / "framework, data" / "method, eval, close"
- If audience is technical (engineers), emphasize sections 6–7
- If audience is academic (committee), emphasize sections 1–3

---

# Slide 3 — Background: Why LLMs?

**Time:** ~1 minute 30 seconds

### 🇹🇭 Thai
> เริ่มจากภาพใหญ่นะครับ ตั้งแต่ ChatGPT เปิดตัวในปี 2022 โมเดล LLM อย่าง
> GPT-4, Gemini 1.5, Claude และ Llama ได้สร้างมาตรฐานใหม่ในงาน NLP ทุกประเภท
>
> โดยเฉพาะในวงการการศึกษา LLM ถูกนำมาใช้กับงานหลากหลาย ไม่ว่าจะเป็นการ
> วินิจฉัยความเข้าใจของผู้เรียน การให้คะแนนอัตโนมัติ หรือการตอบคำถามจากตำรา
> รวมถึงการเป็น tutor ที่พร้อมให้บริการ 24 ชั่วโมง
>
> สถิติทางขวาน่าสนใจครับ — LLM ทำคะแนนเทียบเท่านักศึกษาในมากกว่า 10
> รายวิชา และครอบงำ 70% ของ NLP benchmarks ปัจจุบัน
>
> แต่ตัวเลขที่สำคัญที่สุดคือตัวสุดท้าย — **น้อยกว่า 1%** ของงานวิจัย
> LLM-education มุ่งเน้นภาษาไทยหรือภาษาที่มีทรัพยากรจำกัด นั่นคือ
> **ช่องว่างที่งานนี้จะเข้ามาเติม**

### 🇬🇧 English
> Let me start with the big picture. Since ChatGPT launched in 2022, LLMs
> like GPT-4, Gemini 1.5, Claude, and Llama have set new benchmarks
> across NLP tasks.
>
> In education specifically, LLMs are now powering a wide range of
> applications: cognitive diagnosis of learners, automated grading,
> textbook question answering, and 24/7 personalized tutoring.
>
> The statistics on the right are striking — LLMs match student-level
> performance on more than 10 subjects, and now dominate 70% of NLP
> benchmarks.
>
> But the most important number is the last one — **less than 1%** of
> LLM-in-education research focuses on Thai or low-resource languages.
> **That's the gap this project fills.**

### 📝 Speaker notes
- **Emphasis point:** stress "less than 1%" — this is your motivation in a single number
- Pause briefly after the gap statement; let it land
- If a committee member asks "where did the <1% come from", say: "based on a review of Web of Science and ACL Anthology papers from 2023–2025 with 'LLM' and 'education' keywords; happy to share the analysis"
- Transition: "Let me now narrow down to the specific problems in Thailand"

---

# Slide 4 — Problem Statement

**Time:** ~1 minute 30 seconds

### 🇹🇭 Thai
> ในบริบทไทยมี 4 ปัญหาหลักครับ
>
> ปัญหาแรก **Institutional Variability** — แต่ละมหาวิทยาลัยมีระเบียบเฉพาะ
> ของตัวเอง นอกเหนือจากที่ พ.ร.บ. การศึกษาแห่งชาติกำหนด ทำให้ข้อมูล
> โครงสร้างไม่ตรงกันและคำศัพท์ก็แตกต่าง
>
> ปัญหาที่สอง **Data Standardization** — เมื่อระเบียบหลากหลาย การรวมข้อมูล
> จากหลายสถาบันก็ยาก ประเทศไทยยังไม่มี schema กลางที่จะทำ unified dataset
>
> ปัญหาที่สาม **Scarcity of Thai QA Datasets** — ชุดข้อมูล Q&A ภาษาไทยใน
> โดเมนบริหารการศึกษาแทบจะไม่มีเลยในที่สาธารณะ ต้องสร้างใหม่ตั้งแต่ต้น
>
> ปัญหาที่สี่ **Limited Compute Resources** — สถาบันส่วนใหญ่มี GPU เพียง
> 1-2 ตัว ทำให้ full fine-tuning ของโมเดลใหญ่เป็นไปไม่ได้

### 🇬🇧 English
> In the Thai context, we face four core problems.
>
> First, **Institutional Variability** — each university has its own
> internal rules on top of the National Education Act, which produces
> inconsistent data structures and terminology across institutions.
>
> Second, **Data Standardization** — diverse regulations make merging
> data across institutions hard. Thailand doesn't yet have a common
> schema for unified datasets.
>
> Third, **Scarcity of Thai QA Datasets** — public Thai Q&A datasets in
> the educational management domain are essentially non-existent. We
> have to build one from scratch.
>
> Fourth, **Limited Compute Resources** — most institutions have only
> 1 to 2 GPUs available, making full fine-tuning of large LLMs
> impractical.

### 📝 Speaker notes
- Go through the 4 cards left-to-right, top-to-bottom (reading order)
- Spend ~20 seconds on each
- Likely question: "Aren't there Thai datasets from NSTDA or NECTEC?"
  Answer: "There are general Thai NLP datasets, but none specifically for
  educational management Q&A. The closest is ThaiQA which targets Wikipedia
  facts, not institutional regulations."
- Transition: "These problems aren't unique to Thailand. A team in Vietnam
  faced the same constraints and published their solution earlier this year."

---

# Slide 5 — Reference Paper: VietEduFrame

**Time:** ~1 minute 30 seconds

### 🇹🇭 Thai
> งานต้นฉบับคือ **VietEduFrame** จากทีม VNU Hanoi เผยแพร่บน arXiv เมื่อ
> มกราคม 2025
>
> ผู้เขียนเสนอ 3 contributions
>
> **Contribution 1 คือ Framework** — pipeline 4 ขั้นที่ทำซ้ำได้ ประกอบด้วย
> LLM pre-label, human refinement, LoRA fine-tuning, และ evaluation loop
>
> **Contribution 2 คือ Dataset** — ชุดข้อมูล 985 ตัวอย่างจากระเบียบของ VNU
> เป็นชุด Context-Question-Answer triples ชุดแรกของเวียดนามในโดเมนนี้
>
> **Contribution 3 คือ LoRA Model** — พิสูจน์ว่า fine-tune Vistral-7B ด้วย LoRA
> บน 1 GPU ทำได้จริง และได้ F1 = 81.24
>
> **ผมจะอธิบายให้เห็นว่า framework และ dataset นี้ generalize มายังภาษาไทย
> ได้ ในขณะที่ปรับให้เหมาะกับลักษณะเฉพาะของภาษาไทย**

### 🇬🇧 English
> The reference work is **VietEduFrame**, from the VNU Hanoi team,
> published on arXiv in January 2025.
>
> The authors present three contributions.
>
> **Contribution 1: a Framework** — a 4-stage reproducible pipeline:
> LLM pre-labeling, human refinement, LoRA fine-tuning, and an
> evaluation loop.
>
> **Contribution 2: a Dataset** — 985 examples derived from VNU
> regulations, the first Vietnamese Context-Question-Answer triples in
> this domain.
>
> **Contribution 3: a LoRA Model** — they showed that fine-tuning
> Vistral-7B with LoRA on a single GPU is feasible and reaches F1 of 81.24.
>
> **My argument is that this framework and dataset construction approach
> generalizes to Thai while we adapt to Thai-specific properties.**

### 📝 Speaker notes
- This slide is the "anchor" of your talk — be clear and confident
- Likely question: "Why this paper and not [other LLM-edu paper]?"
  Answer: "Because of three specific properties — low-resource language,
  single-GPU constraint, and published reproducible pipeline. Other LLM-edu
  work mostly uses English on multi-GPU clusters."
- Don't read all the bullets — group them: "framework = pipeline, dataset = 985 examples, model = F1 81"

---

# Slide 6 — Key Results from VietEduFrame

**Time:** ~1 minute 30 seconds

### 🇹🇭 Thai
> มาดูผลลัพธ์ของเปเปอร์ต้นฉบับครับ
>
> กราฟทางซ้ายเปรียบเทียบ 4 setups: Bloom กับ Vistral, แต่ละโมเดลทดสอบทั้ง
> LoRA และ full fine-tuning
>
> สังเกตุ 2 จุด:
> หนึ่ง — **Vistral ชนะ Bloom ประมาณ 10 จุดของ F1** สำหรับโมเดลที่ pre-train
> บนภาษาเป้าหมายโดยตรง
> สอง — **LoRA กับ full fine-tuning ให้ผลใกล้เคียงกันมาก** ต่างกันไม่ถึง 0.5 F1
>
> ตารางทางขวาขยายความ — LoRA ลดเวลา training ลง 57% และลด GPU RAM ลง 48%
>
> **นี่คือ takeaway สำคัญ:** LoRA ลด compute ลงเกือบครึ่งหนึ่งโดยที่ความแม่นยำ
> แทบไม่ลดลงเลย ทำให้สามารถใช้กับห้องแล็ปมหาวิทยาลัยที่มี GPU ตัวเดียวได้

### 🇬🇧 English
> Now let me show the results from the reference paper.
>
> The chart on the left compares 4 setups: Bloom versus Vistral, each
> tested with both LoRA and full fine-tuning.
>
> Two things to notice.
> First — **Vistral beats Bloom by about 10 F1 points**. The model
> pre-trained on the target language wins.
> Second — **LoRA and full fine-tuning give nearly identical results** —
> less than 0.5 F1 difference.
>
> The table on the right zooms in: LoRA cuts training time by 57% and
> GPU RAM by 48%.
>
> **This is the key takeaway:** LoRA roughly halves the compute cost
> while keeping accuracy essentially unchanged. That makes this approach
> practical for any lab with a single GPU.

### 📝 Speaker notes
- **Point at the chart** as you say "Vistral beats Bloom"
- **Point at the table** as you say "LoRA cuts training time"
- Likely question: "Why is the gap only 0.5 F1? Is that statistically significant?"
  Answer: "The paper reports it as numerical comparison without significance tests.
  For my reproduction, I plan to run 3 seeds and report mean ± std."
- Transition: "So that's the proof of concept. Let me show how I adapt this to Thai."

---

# Slide 7 — Our Adaptation: ThaiEduFrame

**Time:** ~1 minute 30 seconds

### 🇹🇭 Thai
> หัวข้อนี้คือหัวใจของโปรเจคครับ — **ThaiEduFrame**
>
> ทางซ้ายคือสิ่งที่เรา **รักษาไว้** จากเปเปอร์ต้นฉบับ:
> หนึ่ง — โครงสร้าง pipeline เดิม
> สอง — การสร้าง synthetic data ด้วย LLM ตัวใหญ่
> สาม — รูปแบบ Context-Question-Answer triples
> สี่ — metrics EM และ F1 รวมถึง human review
>
> ทางขวาคือสิ่งที่เรา **เปลี่ยน** สำหรับภาษาไทย:
> หนึ่ง — เลือก base model ที่ pre-train บนภาษาไทยโดยตรง คือ Typhoon-7B
> สอง — แหล่งข้อมูลเป็นระเบียบมหาวิทยาลัยไทย
> สาม — ปรับ tokenizer ให้รองรับภาษาไทยซึ่งไม่มีช่องว่างระหว่างคำ
> สี่ — เพิ่มขั้นตอน word segmentation ด้วย PyThaiNLP
>
> ด้านล่างคือ pipeline visualization — เริ่มจากเอกสารดิบ จนถึง evaluation 6 ขั้น

### 🇬🇧 English
> This slide is the core of my project — **ThaiEduFrame**.
>
> On the left, what we **keep** from the original paper:
> One — the pipeline structure.
> Two — synthetic data generation with a strong LLM.
> Three — the Context-Question-Answer triple format.
> Four — Exact Match and F1 metrics, plus human review.
>
> On the right, what we **change** for Thai:
> One — base model: a Thai-pretrained LLM, Typhoon-7B.
> Two — source documents: Thai university regulations.
> Three — tokenizer adaptation, because Thai has no whitespace between words.
> Four — adding a word-segmentation preprocessing step with PyThaiNLP.
>
> The diagram at the bottom shows the full 6-step pipeline, from raw
> documents to evaluation.

### 📝 Speaker notes
- The left/right contrast is the slide's structure — point at each side as you mention it
- Likely question: "Why Typhoon and not OpenThaiGPT?"
  Defer to slide 10 — say: "Great question, I have a dedicated slide on model selection coming up"
- Transition: "Let me drill into how the dataset is built."

---

# Slide 8 — Dataset Construction Process

**Time:** ~1 minute 30 seconds

### 🇹🇭 Thai
> Dataset construction มี 5 ขั้นตอน
>
> **ขั้นที่ 1 Collect** — รวบรวมระเบียบจากมหาวิทยาลัยไทย เริ่มจาก CU, TU, KU,
> CMU เป็นต้น
>
> **ขั้นที่ 2 Preprocess** — ตัดคำด้วย PyThaiNLP ทำความสะอาดข้อความ และแปลง
> สูตรคณิตศาสตร์เป็น KaTeX
>
> **ขั้นที่ 3 Prompt Design** — ใช้เทคนิคการ prompt ขั้นสูง: Chain-of-Thought,
> Self-Consistency, และ Tree of Thought
>
> **ขั้นที่ 4 Generate** — ป้อน prompts ที่ออกแบบแล้วเข้า GPT-4 หรือ Claude
> เพื่อสร้าง Context-Question-Answer triples แบบ synthetic
>
> **ขั้นที่ 5 Evaluate** — ประเมินด้วย automated metrics เช่น ROUGE/BLEU
> และ human review ตาม 5-level quality scale
>
> เป้าหมายสุดท้ายที่ด้านล่าง: ประมาณ **1,500 Q-A pairs** จาก 60+ articles
> ของ 5 สถาบัน โดยอย่างน้อย 85% ต้องผ่านการ validate ด้วยมนุษย์

### 🇬🇧 English
> Dataset construction has 5 stages.
>
> **Stage 1, Collect** — gather regulations from Thai universities,
> starting with Chulalongkorn, Thammasat, Kasetsart, Chiang Mai.
>
> **Stage 2, Preprocess** — tokenize with PyThaiNLP, clean the text,
> and convert math formulas to KaTeX.
>
> **Stage 3, Prompt Design** — use advanced prompting techniques:
> Chain-of-Thought, Self-Consistency, and Tree of Thought.
>
> **Stage 4, Generate** — feed the designed prompts to GPT-4 or Claude
> to produce synthetic Context-Question-Answer triples.
>
> **Stage 5, Evaluate** — use automated metrics like ROUGE and BLEU,
> plus human review with a 5-level quality scale.
>
> The target statistics at the bottom: roughly **1,500 Q-A pairs** from
> 60+ articles across 5 institutions, with at least 85% passing human
> validation.

### 📝 Speaker notes
- Count off "1, 2, 3, 4, 5" with your fingers as you go through the cards
- The bottom row of statistics is your **commitment** — these are targets you can be questioned on
- Likely question: "Is 1,500 enough?"
  Answer: "The reference paper used 985 and got F1 81. 1,500 with Thai-specific
  diversity should be sufficient. If not, we have a clear path to scale up via
  more synthetic generation."

---

# Slide 9 — Example Data Point

**Time:** ~1 minute

### 🇹🇭 Thai
> นี่คือตัวอย่างจริงของ data point หนึ่งในชุดข้อมูล
>
> **Context** ด้านบน คือเนื้อหาจากระเบียบ ข้อ 16 ว่าด้วยภาคการศึกษา
> ผมแสดงทั้งคำแปลภาษาอังกฤษไว้ก่อน และต้นฉบับภาษาไทยด้านล่าง
>
> **Question** ทางซ้าย คือคำถามที่นิสิตน่าจะถาม — "ในหนึ่งปีการศึกษามีภาค
> การศึกษาปกติและภาคฤดูร้อนกี่ภาค"
>
> **Answer** ทางขวา คือคำตอบที่ระบุคำตอบและอ้างถึงข้อในระเบียบ
>
> ลักษณะของ data point ตรงนี้สำคัญ: **คำตอบไม่ใช่แค่ extract เนื้อหา**
> แต่เป็นการสังเคราะห์เนื้อหาเป็นภาษาที่ตอบคำถามตรงประเด็น พร้อมอ้างอิงข้อ

### 🇬🇧 English
> This is one actual data point from the dataset.
>
> The **Context** at the top is from Article 16 of the regulations, on
> academic semesters. I show the English translation first, with the
> original Thai underneath for reference.
>
> The **Question** on the left is what a student might realistically
> ask — "How many regular and summer semesters are in one academic year?"
>
> The **Answer** on the right gives the answer and cites the article.
>
> An important property of this data point: **the answer is not just an
> extract** — it's a synthesis in natural language that directly addresses
> the question while citing the source article.

### 📝 Speaker notes
- Reading the Thai aloud is optional — only do it if the audience is fully Thai-speaking
- If audience is mixed, just read the English; the Thai is on-slide for transparency
- Emphasize "not just an extract" — distinguish this from search/RAG
- Likely question: "Could RAG solve this without fine-tuning?"
  Answer: "RAG handles the lookup but not the synthesis. Slide 16 shows
  retrieval gets only F1 ~33, vs 80+ for fine-tuned models."

---

# Slide 10 — Base Model Candidates

**Time:** ~1 minute 15 seconds

### 🇹🇭 Thai
> มาตอบคำถาม "ทำไม Typhoon" กันครับ ตารางนี้เปรียบเทียบ 5 candidate models
>
> **Typhoon-7B จาก SCB 10X** — Thai-extended tokenizer, Apache 2.0 license
> เป็นตัวเลือกหลัก
>
> **OpenThaiGPT-7B** — community-driven, มี instruction-tuned variants
> เป็นตัวเลือกสำรอง
>
> **SeaLLM-7B-v2** — multilingual SE-Asian รวมถึงไทย แต่ license เป็น
> research only
>
> **Llama-3-8B + Thai LoRA** — ต้องใช้ adapter เพิ่ม เพราะ tokenizer ดั้งเดิม
> ไม่ optimize สำหรับไทย
>
> และสุดท้าย **Bloom-7B** — เก็บเป็น baseline เพื่อเทียบกับเปเปอร์ต้นฉบับ
>
> กล่องด้านล่าง: **Typhoon-7B + LoRA เป็น primary model** ของเรา เพราะมี
> Thai tokenizer ที่ดีที่สุดและ Apache license

### 🇬🇧 English
> Let me answer the "why Typhoon" question. This table compares 5
> candidate models.
>
> **Typhoon-7B from SCB 10X** — Thai-extended tokenizer, Apache 2.0
> license. This is our primary choice.
>
> **OpenThaiGPT-7B** — community-driven, with instruction-tuned variants
> available. A strong fallback.
>
> **SeaLLM-7B-v2** — multilingual SE-Asian including Thai, but the
> license is research-only.
>
> **Llama-3-8B with Thai LoRA** — requires an adapter because the
> default tokenizer isn't optimized for Thai.
>
> Finally, **Bloom-7B** — kept as a baseline to mirror the reference
> paper for fair comparison.
>
> The bottom highlight: **Typhoon-7B + LoRA as primary model**. The best
> Thai tokenizer coverage and a permissive license make it the obvious choice.

### 📝 Speaker notes
- "SCB 10X" — pronounce as "SCB ten X" (it's a real research lab in Bangkok)
- Likely question: "What about closed models — Claude, GPT-4?"
  Answer: "Reserved for synthetic data generation, not deployment.
  For deployment we need an open weight model the university can host."
- Transition: "Let me explain *how* LoRA works."

---

# Slide 11 — Why LoRA?

**Time:** ~2 minutes

### 🇹🇭 Thai
> สมการทางซ้ายคือหัวใจของ LoRA ครับ
>
> เมื่อมี input vector h_in ที่จะส่งเข้า layer ปกติ output จะเป็น W₀ คูณ h_in
> โดยที่ W₀ เป็น weight matrix ที่ pre-train มาแล้วและ **ตรึงไว้ไม่ฝึกซ้ำ**
>
> LoRA เพิ่ม **delta** เล็กๆ คือ W_up คูณ W_down — โดย W_down เป็น matrix
> rank ต่ำขนาด r คูณ k, และ W_up ขนาด d คูณ r เริ่มต้นเป็นศูนย์ทั้งหมด
>
> ความสำคัญคือ — **เรา fine-tune แค่ W_up กับ W_down** ซึ่งมีพารามิเตอร์น้อย
> กว่าทั้ง W₀ ประมาณ 200 เท่า
>
> ทางขวาคือสรุปประโยชน์: ลด GPU RAM ลง 48%, ลดเวลา training ลง 57%,
> performance drop น้อยกว่า 0.5 F1 และ adapter เล็ก ทำให้ swap LoRA
> สำหรับแต่ละสถาบันได้

### 🇬🇧 English
> The equation on the left is the heart of LoRA.
>
> When an input vector h_in flows through a normal layer, the output is
> W-zero times h_in, where W-zero is the pre-trained weight matrix —
> and we **freeze it** during fine-tuning.
>
> LoRA adds a small **delta**: W_up times W_down, where W_down is a
> low-rank r-by-k matrix and W_up is d-by-r, initialized to all zeros.
>
> The key point is — **we only fine-tune W_up and W_down**, which have
> about 200 times fewer parameters than W-zero.
>
> The right side summarizes the benefits: 48% less GPU RAM, 57% less
> training time, less than 0.5 F1 performance drop, and adapters are
> small enough that you can swap a different LoRA per institution.

### 📝 Speaker notes
- **Slow down** on this slide — math makes audiences nervous
- Use your hands: one hand stays still ("frozen W₀"), the other wiggles ("trainable delta")
- "Zero" initialization for W_up is **deliberate** — it means LoRA starts at the original behavior. Mention this if asked
- Likely question: "Why rank 128 specifically?"
  Answer: "It matches the reference paper. Lower (16, 32) under-fits on regulation
  text; higher (256+) costs more compute without F1 gain. I'd run an ablation
  if results suggest otherwise."

---

# Slide 12 — Code: Thai Text Preprocessing

**Time:** ~1 minute

### 🇹🇭 Thai
> ทีนี้มาดู code จริงครับ
>
> Block แรก `clean_thai_text` — ทำ unicode normalize, collapse spaces, และ
> ลบ zero-width characters ที่มักติดมาจากการ copy-paste
>
> Block ที่สอง `build_triple` — รับ article (เป็น dict) ทำความสะอาด context
> แล้วตัดคำด้วย `word_tokenize` engine "newmm" ของ PyThaiNLP จากนั้น return
> เป็น dict ที่มี article_id, context, tokens, n_tokens, และ institution
>
> สังเกตว่าโค้ดง่ายมาก — เรากำลังใช้ tool ที่มีอยู่แล้ว ไม่ได้สร้างใหม่

### 🇬🇧 English
> Now let me show actual code.
>
> The first block, `clean_thai_text` — does Unicode normalization,
> collapses whitespace, and removes zero-width characters that often
> sneak in from copy-paste.
>
> The second block, `build_triple` — takes an article as a dict, cleans
> the context, then tokenizes with PyThaiNLP's `word_tokenize` using the
> "newmm" engine. It returns a dict with article_id, context, tokens,
> token count, and institution.
>
> Notice how simple this is — we're standing on existing tools, not
> building from scratch.

### 📝 Speaker notes
- Don't read the code line-by-line. Highlight the **two functions** and what each does
- Move your laser pointer / cursor to the relevant block as you speak
- Likely question: "Why 'newmm' and not other tokenizers?"
  Answer: "Best speed/quality trade-off in PyThaiNLP. If F1 underperforms
  I'd try 'attacut' which is slower but more accurate on ambiguous text."

---

# Slide 13 — Code: LLM-Based QA Generation

**Time:** ~1 minute 15 seconds

### 🇹🇭 Thai
> Slide นี้แสดงวิธีสร้าง Q&A pairs ด้วย LLM
>
> ส่วนบน — `PROMPT` template สั่ง LLM ว่า:
> 1. คิดทีละขั้น (Chain-of-Thought) ว่าประเด็นสำคัญในบริบทคืออะไร
> 2. สร้างคำถาม 3 ข้อที่นิสิตน่าจะถาม
> 3. ตอบแต่ละข้อกระชับ พร้อมอ้างอิงข้อ
> และให้ return ผลเป็น JSON
>
> ส่วนล่าง — function `generate_qa` ส่ง prompt ไปที่ Claude หรือ GPT-4
> แล้ว parse JSON ที่ได้กลับมาเป็น list ของ dict
>
> สังเกตว่า **prompt design ทำหน้าที่สำคัญ** — ถ้า prompt ไม่ดี output ก็ไม่ดี
> Chain-of-Thought เป็นเทคนิคที่ proven ว่าเพิ่มความหลากหลายของคำถามได้

### 🇬🇧 English
> This slide shows how we generate Q&A pairs with an LLM.
>
> Top — the `PROMPT` template tells the LLM to:
> 1. Think step-by-step (Chain-of-Thought) about the key topics
> 2. Generate 3 questions a student might ask
> 3. Answer each concisely, citing the source article
> And return results as JSON.
>
> Bottom — the `generate_qa` function sends the prompt to Claude or
> GPT-4, then parses the returned JSON into a list of dicts.
>
> Notice that **prompt design carries a lot of weight here** — bad
> prompts produce bad outputs. Chain-of-Thought is well-documented to
> improve question diversity.

### 📝 Speaker notes
- Highlight the "Think step-by-step" line specifically — that's where CoT activates
- Likely question: "Don't synthetic data sets introduce bias?"
  Answer: "Yes, and that's why we follow with human review — slide 17 lists
  this as a known limitation with a concrete mitigation."

---

# Slide 14 — Code: LoRA Fine-Tuning

**Time:** ~1 minute 30 seconds

### 🇹🇭 Thai
> ตอนนี้เข้าสู่ part ที่ technical ที่สุด — LoRA fine-tuning ด้วย Hugging Face
> PEFT
>
> 3 บรรทัดบน — import libraries: transformers, peft, datasets
>
> บรรทัด `MODEL` กำหนด Typhoon-7B เป็น base model
>
> Block `LoraConfig` คือหัวใจ:
> - rank r=128
> - alpha=256 (มาตรฐานคือ 2×r)
> - dropout=0.1
> - target_modules คือ q, k, v, o projections ใน attention layer
>
> หลังจาก `get_peft_model` โมเดลจะมี trainable parameters แค่ประมาณ 0.5%
> ของทั้งหมด
>
> ส่วนล่าง — โหลด JSONL dataset, tokenize, แล้วใช้ Trainer ของ Hugging Face
> เพื่อ fine-tune หลังเสร็จก็บันทึก LoRA adapter ลงดิสก์

### 🇬🇧 English
> This is the most technical slide — LoRA fine-tuning with Hugging Face PEFT.
>
> The top 3 lines import libraries: transformers, peft, datasets.
>
> The `MODEL` constant points to Typhoon-7B as the base.
>
> The `LoraConfig` block is the heart of this slide:
> - rank r=128
> - alpha=256, which is standard 2-times-r
> - dropout=0.1
> - target_modules are the q, k, v, o projections in the attention layer
>
> After `get_peft_model`, the model has only about 0.5% trainable
> parameters of the original.
>
> Bottom — we load the JSONL dataset, tokenize it, and use Hugging
> Face's Trainer to fine-tune. When done, we save the LoRA adapter to disk.

### 📝 Speaker notes
- This is your **most technical** slide. Read your audience: if blank faces, slow down. If nods, speed up.
- The "0.5% trainable" line is your wow-moment — emphasize it
- Likely question: "Why only attention layers, not MLP?"
  Answer: "Empirically matches the reference paper. Adding MLP gives marginal
  gain on small datasets but doubles parameter count. We could ablate."

---

# Slide 15 — Code: Evaluation

**Time:** ~1 minute 15 seconds

### 🇹🇭 Thai
> Slide สุดท้ายของ code section คือ evaluation
>
> Function `normalize` — แค่ strip whitespace, replace, lowercase สำหรับ
> เปรียบเทียบ exact match
>
> `exact_match` — ถ้า normalize แล้วเท่ากัน คะแนน 1.0, ไม่งั้น 0.0
>
> `f1_score` คือ token-level F1:
> 1. ตัดคำทั้ง prediction และ gold answer ด้วย newmm
> 2. นับ tokens ที่ทับซ้อนกันด้วย Counter intersection
> 3. คำนวณ precision และ recall
> 4. return F1 = 2pr / (p+r)
>
> Function `evaluate` ด้านล่างวนลูปทั้ง test set, เก็บคะแนน, return mean เป็น
> percentage

### 🇬🇧 English
> The last code slide is evaluation.
>
> The `normalize` function strips whitespace, removes spaces, lowercases,
> so we can compare for exact match.
>
> `exact_match` returns 1.0 if normalized strings are equal, else 0.0.
>
> `f1_score` is token-level F1:
> 1. Tokenize both prediction and gold answer with newmm.
> 2. Count overlapping tokens with a Counter intersection.
> 3. Compute precision and recall.
> 4. Return F1 = 2pr / (p+r).
>
> The `evaluate` function at the bottom loops over the test set, collects
> scores, and returns the mean as a percentage.

### 📝 Speaker notes
- This is straightforward — don't dwell
- Likely question: "Why not use BLEURT or BERTScore for Thai?"
  Answer: "EM and F1 match the reference paper for direct comparison.
  Embedding-based metrics would be a future extension."

---

# Slide 16 — Expected Results

**Time:** ~1 minute 30 seconds

### 🇹🇭 Thai
> ก่อนรันการทดลองจริง ผมจะพยากรณ์ผลลัพธ์ตาม 3 hypothesis
>
> **H1: Thai-pretrained models beat multilingual ones** — Typhoon ควรจะชนะ
> Bloom ประมาณ 10 F1 points สะท้อนแบบเดียวกับที่ Vistral ชนะ Bloom ใน
> เปเปอร์ต้นฉบับ
>
> **H2: LoRA matches full fine-tune** — ห่างกันไม่เกิน 1 F1 point แต่ประหยัด
> GPU RAM และเวลา training ประมาณ 50%
>
> **H3: Synthetic data is sufficient with human refinement** — dataset
> แบบ 70% synthetic + 30% human refinement น่าจะให้ผลดีกว่า dataset เล็ก
> ที่ทำด้วยมนุษย์ทั้งหมดในเวลาเท่ากัน
>
> กราฟทางซ้ายแสดงตัวเลขที่คาดการณ์: Typhoon + LoRA น่าจะได้ F1 ~82 ใกล้กับ
> full fine-tune ที่ 83

### 🇬🇧 English
> Before running the actual experiments, here are my three hypotheses to test.
>
> **H1: Thai-pretrained models beat multilingual ones** — Typhoon should
> beat Bloom by about 10 F1 points, mirroring the Vistral-vs-Bloom gap
> in the original paper.
>
> **H2: LoRA matches full fine-tune** — within 1 F1 point of full
> fine-tuning, but saving roughly 50% on GPU RAM and training time.
>
> **H3: Synthetic data is sufficient with human refinement** — a 70%
> synthetic plus 30% human-refined dataset should outperform a smaller
> fully-human dataset built with the same total effort budget.
>
> The chart on the left shows projected numbers: Typhoon + LoRA reaching
> F1 around 82, close to full fine-tune at 83.

### 📝 Speaker notes
- The **3 hypotheses are testable claims** — committee members love this format
- These are not just predictions; they're falsifiable statements your experiment can confirm or refute
- Likely question: "What if H1 doesn't hold?"
  Answer: "Then that's an interesting negative result. It would suggest that
  Vietnamese and Thai have different pretraining sensitivities — worth a
  follow-up analysis."

---

# Slide 17 — Timeline & Limitations

**Time:** ~1 minute 30 seconds

### 🇹🇭 Thai
> ปิดด้วย timeline และข้อจำกัดที่รู้ตัว
>
> **8-Month Roadmap:**
> - M1-2 Data Collection
> - M3 Preprocessing
> - M4-5 Synthetic Data Generation
> - M6 Fine-tune LoRA
> - M7 Evaluation
> - M8 Paper writing + demo
>
> **ข้อจำกัดที่เรารับรู้:**
>
> ข้อแรก — **Reasoning Depth** — multi-step หรือ numerical reasoning ใน
> regulation clauses ยังเปราะบาง โดยเฉพาะเมื่อ context ยาวกว่า 1000 tokens
>
> ข้อสอง — **Institutional Coverage** — เริ่มจาก 5 universities การ generalize
> ไป vocational หรือ K-12 ต้องการ data เพิ่ม
>
> ข้อสาม — **Synthetic Data Bias** — คำถามที่ generated โดย GPT มักเน้นการ
> lookup factual มากกว่า policy interpretation human review ช่วยลดได้แต่
> ไม่หมด

### 🇬🇧 English
> Let me close with the timeline and known limitations.
>
> **8-Month Roadmap:**
> - M1-2: Data Collection
> - M3: Preprocessing
> - M4-5: Synthetic Data Generation
> - M6: Fine-tune with LoRA
> - M7: Evaluation
> - M8: Paper writing and demo
>
> **Known limitations:**
>
> First — **Reasoning Depth** — multi-step or numerical reasoning over
> regulation clauses is still fragile, especially when contexts exceed
> 1000 tokens.
>
> Second — **Institutional Coverage** — we start with 5 universities.
> Generalizing to vocational colleges or K-12 will require additional data.
>
> Third — **Synthetic Data Bias** — GPT-generated questions tend to
> over-represent factual lookup versus policy interpretation. Human
> review mitigates but doesn't eliminate this.

### 📝 Speaker notes
- **Be honest about limitations** — committee respect goes up, not down, when you proactively name weaknesses
- Each limitation has a known mitigation strategy (in the methodology doc) — be ready to discuss if asked
- Likely question: "How do you handle long contexts?"
  Answer: "RAG layered on top of fine-tuning — chunk articles into 800-char
  segments with 200-char overlap, retrieve top-3 per query."

---

# Slide 18 — Thank You / Q&A

**Time:** ~30 seconds + Q&A

### 🇹🇭 Thai
> ขอบคุณครับ
>
> **Next Steps ของผม:**
> หนึ่ง — เซ็น MOU แลกเปลี่ยนข้อมูลกับ 5 มหาวิทยาลัยพันธมิตร
> สอง — เตรียมสภาพแวดล้อม GPU (1 ตัว A100 หรือ 2 ตัว RTX 4090)
> สาม — เริ่ม pilot data generation จากระเบียบจุฬาฯ ก่อน
> สี่ — reproduce VietEduFrame baselines บน Vi-test ก่อนปรับมาภาษาไทย
>
> ตอนนี้พร้อมรับคำถามครับ

### 🇬🇧 English
> Thank you.
>
> **My next steps:**
> One — secure data-sharing MOUs with 5 partner universities.
> Two — set up the GPU environment (one A100 or two RTX 4090s).
> Three — start pilot data generation on Chulalongkorn regulations.
> Four — reproduce the VietEduFrame baselines on the Vi-test set before
> adapting to Thai.
>
> I'm now happy to take questions.

### 📝 Speaker notes
- **Smile.** Acknowledge applause / nods briefly.
- Take a breath before the first question — gives you composure
- For tough questions, you can buy time with: "That's a great question.
  Let me think for a moment..." or "Could you say more about what you mean by X?"
- If you don't know the answer: "I don't know off the top of my head,
  but I can follow up via email by [date]." — never bluff

---

# Common Q&A Bank

A few questions you should rehearse, in both languages.

### Q1: "Why not just use GPT-4 with a system prompt?"

**🇹🇭** เพราะ 3 เหตุผล: หนึ่ง — เรื่อง privacy ของระเบียบมหาวิทยาลัย, สอง — ต้นทุน
ในการ scale ผู้ใช้หลายหมื่นคน, สาม — ความเฉพาะของภาษาราชการไทยที่ GPT-4 ทั่วไป
อาจจัดการได้ไม่ดี การ fine-tune local model จัดการได้ทั้ง 3 เรื่อง

**🇬🇧** Three reasons: privacy of internal regulations, cost at scale with tens of
thousands of student queries, and the formal Thai legal-administrative
register that generic GPT-4 doesn't handle well. A locally fine-tuned model
addresses all three.

---

### Q2: "What's your evaluation budget for human review?"

**🇹🇭** ประมาณ 40-50 ชั่วโมงรีวิวเวอร์ครับ 1000-1500 examples ที่ 2-3 นาทีต่อ example
ผมตั้งงบนี้ไว้ใน timeline M3-M5 และจะใช้คน 2 คนเพื่อตรวจ inter-annotator agreement
ด้วย Cohen's kappa

**🇬🇧** About 40-50 reviewer-hours, for 1000-1500 examples at 2-3 minutes per row.
Budgeted in the M3-M5 timeline window. Two reviewers in parallel will let me
compute Cohen's kappa for inter-annotator agreement.

---

### Q3: "How do you ensure the model doesn't hallucinate article numbers?"

**🇹🇭** สอง guardrails: หนึ่ง — ใน training data ผม include `article_id` ใน prompt และ
require ให้ model ทำซ้ำใน output. สอง — ใน post-processing ผม regex match ข้อใน
output แล้ว verify ว่ามีจริงในระเบียบ ถ้าไม่จริงก็ strip citation นั้นออก

**🇬🇧** Two guardrails: First, during training I include `article_id` in the prompt and
require the model to repeat it in the answer. Second, at inference I regex-match
article citations in the output and verify they exist in the regulations; if not, I strip them.

---

### Q4: "How will you know if the model is actually useful, not just accurate?"

**🇹🇭** Beyond F1, ผมวางแผน human acceptance rate evaluation — สุ่ม 100 predictions
จาก test set ให้ 2 reviewer label ตาม 5-level quality scale แล้ว report % ที่ได้
Very Good + Good เทียบกับ baseline ของเปเปอร์ต้นฉบับที่ได้ 83%

**🇬🇧** Beyond F1, I'll do a human acceptance rate evaluation — sample 100 predictions
from the test set, have two reviewers label them on the 5-level quality scale,
and report the percentage rated Very Good + Good. The reference paper reached
83%; that's my target.

---

# Pacing tips / เคล็ดลับการพูด

**🇹🇭**
- ฝึกซ้อมจริง 2-3 รอบ จับเวลาด้วย stopwatch
- ถ้าเวลาจำกัด 15 นาที — ย่อ slide 11 (LoRA math) และ slide 14 (code) ลงครึ่งหนึ่ง
- ถ้าเวลามี 30 นาที — ขยาย slide 6 และ slide 16 (results) เพิ่ม
- **อย่าอ่าน script เป๊ะๆ** — ใช้เป็น guide จดจำใจความและพูดเป็นธรรมชาติ

**🇬🇧**
- Rehearse aloud 2-3 times with a stopwatch
- For a tight 15-minute slot — compress slide 11 (LoRA math) and slide 14 (code) by half
- For a generous 30-minute slot — expand slide 6 and slide 16 (results)
- **Don't read this verbatim** — use it as a guide; internalize the structure and speak naturally

---

*End of speaker scripts. Good luck! / ขอให้นำเสนอราบรื่นครับ*
