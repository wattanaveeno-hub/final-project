# Methodology — LLM for Thai Education Management

**Project:** Adapting Large Language Models to Educational Management in Thai
**Reference paper:** Do, Nguyen & Dam (2025). *Using Large Language Models for Education Management in Vietnamese with Low Resources.* arXiv:2501.15022

---

## Table of Contents

1. [Problem Framing & Design Rationale](#1-problem-framing--design-rationale)
2. [Why This Pipeline?](#2-why-this-pipeline)
3. [Stage 1 — Data Collection](#3-stage-1--data-collection)
4. [Stage 2 — Thai Preprocessing](#4-stage-2--thai-preprocessing)
5. [Stage 3 — Synthetic Q&A Generation](#5-stage-3--synthetic-qa-generation)
6. [Stage 4 — Human Refinement & Quality Control](#6-stage-4--human-refinement--quality-control)
7. [Stage 5 — Model Selection](#7-stage-5--model-selection)
8. [Stage 6 — LoRA Fine-Tuning](#8-stage-6--lora-fine-tuning)
9. [Stage 7 — Evaluation](#9-stage-7--evaluation)
10. [Limitations & Mitigations](#10-limitations--mitigations)
11. [Reproducibility Checklist](#11-reproducibility-checklist)

---

## 1. Problem Framing & Design Rationale

### 1.1 The problem in one sentence

Thai universities have **complex internal regulations** (academic policy, leave-of-absence rules, grading systems, graduation criteria), and **students struggle to find quick, accurate answers** to questions about these regulations. Current solutions — searching PDFs, emailing the registrar, asking seniors — are slow, inconsistent, and don't scale.

### 1.2 Why LLMs?

A fine-tuned LLM is a good fit because:

- **Natural-language interface** — students ask in their own words, not regulation-language
- **Compositional answers** — many questions need to combine 2–3 rules ("if GPA < 2.00 AND in semester 4, can I still register for 18 credits?")
- **24/7 availability** — registrar staff are not
- **Scales horizontally** — same model serves 1 or 100,000 students

### 1.3 Why **not** just use GPT-4 / Claude with a system prompt?

Three reasons:

| Issue | Why it matters |
|-------|---------------|
| **Privacy & sovereignty** | University regulations may reference internal documents that institutions are reluctant to send to external APIs |
| **Cost at scale** | A single registrar may handle 50,000+ queries/year; commercial-API cost adds up |
| **Domain-specific phrasing** | Thai regulation language uses formal Royal Thai with specific terms (เทียบโอน, พ้นสภาพ, ทักท้วง) that a generic LLM may mishandle |

A **locally fine-tuned model** addresses all three. This matches the reference paper's motivation for VNU.

### 1.4 Why follow VietEduFrame specifically?

The Vietnamese paper is the closest analog:
- **Same problem class** — university regulation Q&A
- **Same constraints** — low-resource language, single-GPU training budget
- **Published results** — F1 = 81.24 with Vistral-7B + LoRA, gives us a target to match
- **Reproducible pipeline** — every step is described, no proprietary components

We adapt rather than copy: Thai has different tokenization needs, and we have access to Thai-pretrained models (Typhoon, OpenThaiGPT) that didn't exist for Vietnamese in 2024.

---

## 2. Why This Pipeline?

### 2.1 The pipeline at a glance

```
[Raw docs] → [Preprocess] → [Synthetic Q&A gen] → [Human review]
                                                         ↓
                                                  [Training set]
                                                         ↓
[Eval set] ←── [Evaluate model] ←── [LoRA fine-tune] ←──┘
        ↑                                  ↓
        └────────[Error analysis]──────────┘
```

### 2.2 Design principle: separate **data work** from **model work**

A common mistake is to entangle data construction with training. We deliberately keep them separate so each can be improved independently:

- **Data pipeline** can be tested without any GPU (this is what the notebook does)
- **Model pipeline** receives a clean JSONL and just trains
- A bug in either side doesn't require rerunning the other

### 2.3 Design principle: **synthetic + human, not synthetic-only**

The reference paper uses GPT-3.5 to generate Q&A and humans to review. We follow the same pattern because:

| If we use… | Pros | Cons |
|-----------|------|------|
| Only humans | Highest quality | Slow (~5 min/example), expensive, low volume |
| Only LLM-generated | Fast, cheap, large volume | Hallucinations, repetitive patterns, factual errors |
| **Hybrid (LLM + human review)** | Volume **and** quality | Requires reviewer training |

The reference paper achieves ~55% "very good" + ~28% "good" with hybrid. Pure LLM-generated data would likely be ~70% medium-or-worse.

---

## 3. Stage 1 — Data Collection

### 3.1 What we collect

Source documents are **university regulations** as PDF/Word files. Examples:
- ระเบียบมหาวิทยาลัยว่าด้วยการศึกษาระดับปริญญาตรี
- คู่มือนิสิตประจำปีการศึกษา
- ประกาศมหาวิทยาลัยเรื่องการลาพักการศึกษา

### 3.2 Decisions made at this stage

**Decision 1: Single institution first, then expand.**
We start with one university to control variability. The reference paper shows that even 985 examples from a single institution (VNU) is enough to reach F1 = 81. Adding institutions adds complexity (different terminology, different rule structures) that we can defer.

**Decision 2: Article-level granularity, not paragraph or document.**
Each regulation **article** (ข้อ) becomes one unit. Why?
- Articles are typically self-contained (10–50 sentences each)
- They fit comfortably in an LLM's context window (~250–1500 chars)
- They give natural answer scope: "according to Article 16…"

**Decision 3: Manual extraction, not automated PDF parsing.**
PDF parsing of Thai government-style documents is notoriously bad (table-heavy layouts, header/footer noise). For the first dataset, a human copies article-by-article into structured JSON. This is a 1–2 day task and yields cleaner data than 1 week of fighting `pdfplumber`.

### 3.3 Output: `data/raw_regulations.json`

A structured JSON where each article has `id`, `chapter`, `article_no`, `title`, `body`. See [`data/README.md`](../data/README.md) for the full schema.

---

## 4. Stage 2 — Thai Preprocessing

### 4.1 Why preprocessing is non-optional for Thai

Thai has three properties that make raw text problematic:

1. **No inter-word spaces** — "นิสิตต้องลงทะเบียน" is one continuous string; the tokenizer must segment it
2. **Zero-width and combining characters** — copy-pasted text often contains `\u200B`, `\u200C` that look identical but break exact-match
3. **Multiple normalization forms** — the same character can appear as NFC or NFD (e.g. สำ vs ส + ำ)

If we skip preprocessing, F1 drops by ~10 points just from token-mismatch artifacts.

### 4.2 The 4-step clean pipeline (from notebook Section B.1)

```python
def clean_thai(text: str) -> str:
    text = unicodedata.normalize('NFC', text)        # step 1
    text = re.sub(r'[\u200b\u200c\u200d\ufeff]', '', text)  # step 2
    text = re.sub(r'<[^>]+>', '', text)              # step 3
    text = re.sub(r'\s+', ' ', text)                 # step 4
    return text.strip()
```

| Step | Removes | Why |
|------|---------|-----|
| NFC normalize | Decomposed form variants | Same character must hash the same |
| Zero-width strip | Invisible artifacts | Otherwise EM fails on visually-identical strings |
| HTML strip | Tags from web-scraped sources | `<br>` etc. add noise tokens |
| Whitespace collapse | Multi-spaces / tabs / newlines | Standardize for tokenizer |

### 4.3 Tokenizer choice: `newmm` from PyThaiNLP

PyThaiNLP offers several engines:

| Engine | Speed | Accuracy | Choice rationale |
|--------|-------|----------|------------------|
| `newmm` | ⚡⚡⚡ Fast | Good for general text | **Selected** — best speed/quality tradeoff |
| `attacut` | ⚡⚡ Medium | Best for ambiguous text | Use only on `val`/`test` for evaluation |
| `longest` | ⚡⚡⚡ Fastest | Crude | Reject — too many errors on formal Thai |
| `nlpo3` | ⚡⚡ Medium | Best raw accuracy | Use if `newmm` gives F1 < 75 |

We use **`newmm` for training** (volume matters more than perfection) and consider **`attacut` for evaluation** (precision matters more than speed).

### 4.4 Output: a `prompt` column

The cleaned/tokenized text is wrapped in an Alpaca-style template:

```
### คำสั่ง (Instruction):
ตอบคำถามต่อไปนี้โดยอ้างอิงจากบริบทที่ให้

### บริบท (Context):
{context}

### คำถาม (Question):
{question}

### คำตอบ (Answer):
{answer}
```

**Why bilingual labels (Instruction + คำสั่ง)?** Many Thai-pretrained LLMs were continued from English checkpoints. Providing both labels makes the model attend to the right field regardless of which language the pretraining emphasized.

---

## 5. Stage 3 — Synthetic Q&A Generation

### 5.1 The generation prompt (Chain-of-Thought)

For each article body, we ask a strong LLM (Claude Opus / GPT-4) to:

```
You are an expert on Thai university regulations.
Given the following article:
<context>{article_body}</context>

1. Think step by step about what concepts the article covers.
2. Generate 3 questions a student might realistically ask about it.
3. For each, write a concise answer that cites the article.
Return JSON: [{"q": "...", "a": "..."}]
```

### 5.2 Why Chain-of-Thought matters here

Without CoT prompting, generated questions cluster around obvious surface patterns ("What does Article X say?"). With explicit step-1 reasoning, the model produces more diverse questions:
- Factual lookup ("ภาคฤดูร้อนกี่สัปดาห์?")
- Conditional reasoning ("ถ้า GPA = 1.70 ในภาคที่ 4 จะพ้นสภาพไหม?")
- Multi-rule composition ("ลาพักนานสุดได้กี่ภาคทั้งหมด?")
- Definition ("เกรด C+ ค่าเท่าไหร่?")

The reference paper found CoT prompting raised dataset diversity scores by 20%+.

### 5.3 Why 3 questions per article (not 1, not 10)?

Trade-off:
- **1 q/article** → too few examples (985 articles × 1 = 985, would need more articles)
- **10 q/article** → diminishing returns; questions become redundant rephrasings
- **3 q/article** → sweet spot; 985 articles × 3 ≈ 3000 candidates → ~1500 after human filtering

### 5.4 Why use a strong external LLM for generation, but train a smaller open model?

This is **knowledge distillation** in disguise:
- A strong model (Claude/GPT-4) is good at generating high-quality questions but is too expensive/private for production
- Use it once to create the dataset, then **transfer that quality** into a smaller, locally-deployable model

This is also why the reference paper used GPT-3.5 for generation but evaluated on Vistral-7B and Bloom-7B.

### 5.5 Output: candidate Q&A pairs

Each output row joins back to its source article via `article_id`, so we can always trace a Q&A back to the regulation it came from. This is critical for the next stage (human review needs the source).

---

## 6. Stage 4 — Human Refinement & Quality Control

### 6.1 The 5-level quality scale (from the reference paper)

| Level | Description | Action |
|-------|-------------|--------|
| **Very Good** | Accurate, comprehensive, cites article | Keep as-is |
| **Good** | Accurate but minor imprecision | Keep, minor edit |
| **Medium** | Partially correct, missing key detail | Rewrite or drop |
| **Bad** | Mostly wrong, off-topic | Drop |
| **Very Bad** | Completely wrong, hallucinated | Drop + log for prompt improvement |

Reviewer's job is **classification + light editing**, not writing from scratch.

### 6.2 Review process

1. Reviewer opens a candidate row: `(article_body, question, answer)`
2. Reads article (~30 sec)
3. Reads question — is it answerable from the article alone? If no → drop
4. Reads answer — does it actually answer the question? Is it factual?
5. Assigns quality level
6. If Good: minor edit (typo, phrasing) and bump to Very Good if appropriate

Average pace: 2–3 minutes per row. 1000 rows ≈ 40–50 reviewer hours.

### 6.3 Quality control: inter-annotator agreement

For a sample of 100 rows, **two reviewers** label independently. We compute Cohen's κ:
- κ > 0.7 → annotation guidelines are clear; proceed
- κ < 0.7 → refine the scale, retrain reviewers, redo the sample

The reference paper achieved κ ≈ 0.75 on similar work.

### 6.4 Decision: only **Very Good** and **Good** go into training

Medium/Bad/Very Bad are excluded. Even if the model could "learn from noise," the cost of confidently-wrong answers in a production deployment is high. We trade quantity for quality.

### 6.5 Train/val/test split

| Split | Proportion | Used for |
|-------|-----------|----------|
| Train | ~70% | LoRA fine-tuning |
| Val   | ~15% | Hyperparameter tuning, early stopping |
| Test  | ~15% | Final metric report (touched **once** at the end) |

**Stratified by article** so each split contains every topic. Without stratification, a model trained on "leave-of-absence" articles might never see "honors" rules.

---

## 7. Stage 5 — Model Selection

### 7.1 Decision matrix

| Model | Thai pretraining | License | Params | Notes |
|-------|------------------|---------|--------|-------|
| **Typhoon-7B (SCB 10X)** | ✓ Strong (Thai corpus added) | Apache 2.0 | 7B | **Primary choice** |
| OpenThaiGPT-7B | ✓ Strong | Apache 2.0 | 7B | Community-driven; instruction variants exist |
| SeaLLM-7B-v2 | ◐ Multi-SEA (Thai included but not focal) | Research | 7B | Good fallback |
| Llama-3-8B + Thai LoRA | ✗ English-first | Llama 3 | 8B | Tokenizer doesn't compress Thai well |
| Bloom-7B | ◐ Multilingual | BigScience | 7B | **Baseline** (matches the reference paper) |

### 7.2 Why Typhoon-7B as primary

1. **Thai-extended tokenizer** — Typhoon's tokenizer doesn't split common Thai words across 5–7 byte-level tokens like Llama does. Direct effect: ~3x more efficient context use.
2. **Apache 2.0** — no commercial restriction; safe for a university deployment.
3. **SCB 10X is a Thai research lab** — Bangkok-based; documented in Thai; easier to get support for.
4. **Strong on Thai benchmarks** — Typhoon dominates the ThaiLLM-Leaderboard at the time of this proposal.

### 7.3 Why also train Bloom-7B (baseline)

To mirror the reference paper. If Typhoon outperforms Bloom by the same margin as Vistral outperformed Bloom (~10 F1 points), we've replicated the finding **and** demonstrated the result transfers to Thai. If not, that's an interesting negative result worth reporting.

---

## 8. Stage 6 — LoRA Fine-Tuning

### 8.1 What is LoRA?

LoRA (Low-Rank Adaptation) freezes the pretrained weights $W_0$ and adds a small trainable delta:

$$h_{\text{out}} = W_0 h_{\text{in}} + \frac{\alpha}{r} \cdot W_{\text{up}} W_{\text{down}} h_{\text{in}}$$

where:
- $W_0 \in \mathbb{R}^{d \times k}$ — frozen pretrained weights
- $W_{\text{down}} \in \mathbb{R}^{r \times k}$ — trainable, init Gaussian
- $W_{\text{up}} \in \mathbb{R}^{d \times r}$ — trainable, init zero
- $r \ll \min(d, k)$ — the **rank**
- $\alpha$ — scaling factor (typically $\alpha = 2r$)

The trainable parameter count drops by a factor of approximately $\frac{dk}{(d+k) \cdot r}$ ≈ 200× for $d = k = 4096, r = 128$.

### 8.2 Why LoRA instead of full fine-tuning

| Metric | Full FT | LoRA | Savings |
|--------|--------|------|---------|
| Time/epoch (Vistral-7B, ref. paper) | 14 hours | 6 hours | **−57%** |
| GPU RAM | 61.2 GB | 32 GB | **−48%** |
| F1-score | 81.57 | 81.24 | −0.4 points |
| Disk footprint (per model variant) | 14 GB | 80 MB | **−99%** |

**For 0.4 F1 we get ~50% compute savings and a 99% smaller deployable artifact.** This is the central engineering argument of the reference paper.

### 8.3 Hyperparameter rationale

| Hyperparam | Value | Source / reasoning |
|-----------|-------|---------------------|
| `r` (rank) | **128** | Matches reference paper. Lower values (16, 32) under-fit on regulation text; higher (256+) adds compute without F1 gain |
| `alpha` | **256** | Common practice: `alpha = 2 * r` |
| `dropout` | **0.1** | Matches reference paper; small datasets benefit from regularization |
| `target_modules` | **q, k, v, o projections** | Attention-only LoRA matches paper. Adding MLP layers (gate, up, down) gives marginal gain on small datasets |
| `learning_rate` | **2e-4** | Standard for LoRA (10x higher than full-FT LR because deltas are small) |
| `batch_size` | **4** | Fits on a single 24 GB GPU at `max_length=1024` |
| `max_length` | **1024** | Covers 99.5% of context+question+answer triples in our dataset (4446 max but most under 1500) |
| `num_epochs` | **10** | Reference paper used 10. Early-stopping on val loss handles overfit |
| `warmup_ratio` | **0.05** | Standard linear warmup; prevents instability in first few hundred steps |
| `weight_decay` | **0.01** | Mild L2 regularization |

### 8.4 What we **don't** do (and why)

- **No quantization (QLoRA, 4-bit)** in v1. It saves more RAM but introduces another moving part; we add it only if VRAM is tight.
- **No RLHF / DPO**. The task is closed-domain QA; preference-tuning is overkill.
- **No prompt tuning / prefix tuning**. LoRA is empirically stronger on this domain (paper finding).

---

## 9. Stage 7 — Evaluation

### 9.1 The two metrics, restated precisely

**Exact Match (EM):**
$$\text{EM}(p, g) = \begin{cases} 1 & \text{if } \mathrm{normalize}(p) = \mathrm{normalize}(g) \\ 0 & \text{otherwise} \end{cases}$$

where `normalize` lowercases, strips punctuation, applies the same Thai cleaning function as the train pipeline.

**Token-F1:**
$$\text{F1} = \frac{2 \cdot P \cdot R}{P + R}, \quad P = \frac{|p \cap g|}{|p|}, \quad R = \frac{|p \cap g|}{|g|}$$

where $p, g$ are token multisets of prediction and gold, using the **same tokenizer** as training (PyThaiNLP `newmm`).

### 9.2 Why two metrics (and not one)

- **EM** is strict — catches when the model rephrased a perfect answer in different words. Necessary for production: registrars need answers that look "official."
- **F1** is lenient — credits the model when keywords are right but phrasing differs. Necessary for diagnostics: if EM = 0 but F1 = 85, the model knows the answer but is just rewording it.

Reporting both is the standard in extractive QA (SQuAD, etc.) and matches the reference paper.

### 9.3 Sanity tests (from notebook Section C.1)

We **unit-test** the metric implementations before trusting them on real predictions:

```python
assert exact_match('สวัสดี', 'สวัสดี') == 1.0
assert exact_match('สวัสดี', 'สวัสดีครับ') == 0.0
assert f1_score_tokens('สวัสดี', 'สวัสดี') == 1.0
assert 0.0 < f1_score_tokens('GPA ต้องไม่ต่ำกว่า 2.00', 'นิสิตต้องมี GPA ไม่ต่ำกว่า 2.00') < 1.0
```

A metric that fails sanity tests is worthless. **Always run these before reporting numbers.**

### 9.4 Why we additionally simulate 3 baselines in the notebook

(See notebook Section C.2.)

- **Perfect** — copies the gold answer. Should give EM=100, F1=100. If not, the metric is broken.
- **Noisy** — keeps 70% of gold tokens, drops the rest. Should give low EM but high F1. If both are high, the noise model is broken; if both are low, F1 is broken.
- **Bad** — returns an unrelated answer. Should give low EM and low F1. Sets a floor.

This is **scaffolding for the eventual real model**. When the trained model is plugged in, these synthetic baselines provide context: "real model F1 = 78 vs noisy F1 = 80 → real model is *worse* than copy-with-noise → something is wrong."

### 9.5 Why a retrieval baseline is also included

Token Jaccard between the question and each train context. It's a **non-trivial** baseline:
- If the LLM can't beat retrieval, it isn't doing real language understanding
- Reference paper: Vistral+LoRA achieves F1 = 81.24. Retrieval baseline ≈ 30–40. The 40-point gap is what fine-tuning earned.

### 9.6 Human evaluation supplements automatic metrics

For the **final reported number**, we add:
- 100 random test predictions → 2 reviewers label them on the same 5-level scale
- Report % Very-Good + Good as "human acceptance rate"
- Reference paper achieved ~83% acceptance with Vistral+LoRA

This catches cases where F1 is high but the answer is subtly wrong (e.g., correct numbers, wrong condition).

---

## 10. Limitations & Mitigations

### 10.1 Reasoning depth

**Problem:** The model handles factual lookup well but stumbles on multi-step reasoning ("If GPA = 1.70 at end of semester 4, AND I lost the leave-of-absence appeal, can I still graduate?").

**Mitigation:**
- Include explicit multi-step examples (with CoT explanation) in the training data
- At inference time, append "ให้คิดทีละขั้น" ("think step by step") to the prompt — well-documented to improve LLM reasoning
- For very complex queries, fall back to "I'm not sure; please email the registrar at X"

### 10.2 Long-context drift

**Problem:** Articles longer than 1500 chars cause the model to lose track of constraints from the beginning of the context.

**Mitigation:**
- Split long articles into 800-char chunks with 200-char overlap
- For each question, retrieve top-3 chunks then ask model
- This is **RAG** layered on top of fine-tuning

### 10.3 Hallucinated rule numbers

**Problem:** The model may invent article numbers ("according to Article 47…") when uncertain.

**Mitigation:**
- During training, **always** include `article_id` in the prompt and require the model to repeat it in the answer
- Post-process: regex-match for "ข้อ \d+" and verify the cited article exists; if not, strip the citation
- At inference, log mismatches for review

### 10.4 Distribution shift over time

**Problem:** Regulations are updated yearly. A 2024-trained model gives stale 2024 answers in 2027.

**Mitigation:**
- Add a `version` field to each training example
- Retrain (or do continual learning with LoRA) on each regulation update — LoRA's small footprint makes this cheap
- At inference, prepend "ระเบียบฉบับปีการศึกษา 2567" so the model knows which version it's answering for

### 10.5 Synthetic-data bias

**Problem:** GPT-4-generated questions over-represent factual lookup; under-represent the "weird edge case" questions humans actually ask.

**Mitigation:**
- Mine real student questions from registrar email archives (with PII removed)
- Mix 70% synthetic + 30% real → covers diversity better
- Periodically re-run quality review on production logs

### 10.6 Single-institution generalization

**Problem:** A model trained on University X may not generalize to University Y with different numerical thresholds.

**Mitigation:**
- Train **per-institution LoRA adapters** (the killer use case for LoRA — adapters are tiny so we can have one per university)
- Common base model + swap-in adapter at inference time
- Long-term: an MoE-style routing layer that picks the right adapter from a `university_id` token

---

## 11. Reproducibility Checklist

To reproduce this work, you need:

### Compute
- [ ] At least 1× GPU with ≥ 24 GB VRAM (RTX 4090, A100 40 GB, etc.)
- [ ] ~80 GB free disk for base model weights + checkpoints

### Software
- [ ] Python 3.10+
- [ ] `pip install transformers>=4.40 peft>=0.10 datasets accelerate bitsandbytes pythainlp pandas matplotlib`

### Data
- [ ] Raw regulation documents (PDF or Word) — at least 60+ articles
- [ ] Access to a strong LLM API (Claude / GPT-4) for synthetic generation
- [ ] At least 1 domain reviewer with knowledge of Thai academic regulations

### Time budget
- [ ] Data collection: 1–2 days
- [ ] Synthetic generation: 2–4 hours (API calls)
- [ ] Human review: 40–50 hours
- [ ] Fine-tuning: 6–10 hours (LoRA on single GPU)
- [ ] Evaluation + writeup: 1 week

### Code artifacts in this repo
- [x] `data/raw_regulations.json` — example source documents
- [x] `data/thai_edu_qa.jsonl` — example Q&A dataset
- [x] `notebooks/thai_edu_qa_tutorial.ipynb` — end-to-end pipeline demo (no GPU)
- [x] `scripts/finetune_lora.py` — production fine-tuning script (GPU)
- [x] `docs/methodology.md` — this document

---

*End of methodology document. Questions or feedback are welcome.*
